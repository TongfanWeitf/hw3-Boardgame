public interface Board {
    public int getSize();
    public void print();
}
