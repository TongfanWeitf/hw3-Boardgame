public interface BoardGame {
    String getName();
    void Play();
}
