//win conditon check
public interface winConditon {
    public static int winCheck(gameBoard b) {
        return 0;
    }
}
