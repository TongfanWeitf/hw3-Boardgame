//cell to place pieces
public interface Cell {
    String getName();

    void setId(int i);
    int getId();
}
